# Compact Kernel package marker
